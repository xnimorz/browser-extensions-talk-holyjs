(function() {
  'use strict';

  let storedResume = null;
  let shouldSendDataWhenResumeBecameReady = false;
  console.log('PLUGIN');
  console.log(window.test);
  console.log(document.querySelectorAll);
  console.log(document.querySelectorAll('button'));
  window.hello = 'world';

  console.log(document.cookie);
  console.log(localStorage);

  const script =
    "(function(){console.log('I work inside the script tag, from extension'); console.log(document.querySelectorAll('button'))})();";

  const scriptEl = document.createElement('script');
  scriptEl.textContent = script;
  document.body.appendChild(scriptEl);

  const RUNTIME_MESSAGE_ACTIONS = {
    'HHTms-Init': () => {
      sendResume();
    },
  };

  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (!request.action || !RUNTIME_MESSAGE_ACTIONS[request.action]) {
      return;
    }

    RUNTIME_MESSAGE_ACTIONS[request.action](request, sender, sendResponse);
    return true;
  });

  const MUTATION_TIMEOUT = 5000;

  const ACTIONS = {
    actionsUnion: (options) => {
      const actions = options.actions.map((actionConfig) => CreateActionWrapper(actionConfig));
      return Promise.all(actions);
    },
    waitMutation: (options) =>
      new Promise((resolve, reject) => {
        const element = getElement(options);
        const count = options.count || 1;
        let doneCount = 0;

        if (!element) {
          return reject();
        }

        const observer = new MutationObserver(() => {
          if (++doneCount !== count) {
            return;
          }

          clearTimeout(timeout);
          observer.disconnect();
          resolve();
        });
        observer.observe(element, {
          childList: true,
          attributes: true,
          characterData: true,
          subtree: true,
        });

        const timeout = setTimeout(() => {
          observer.disconnect();
          reject();
        }, MUTATION_TIMEOUT);
      }),
    getNodeText: (options) =>
      new Promise((resolve, reject) => {
        const element = getElement(options);
        if (!element) {
          return reject();
        }

        let elementText = element.innerText;
        const patternMatched = !options.patternMatch || new RegExp(options.patternMatch).test(elementText);
        if (options.unnecessaryPart) {
          elementText = elementText.replace(new RegExp(options.unnecessaryPart), '');
        }
        patternMatched ? resolve(elementText.trim()) : reject();
      }),
    getNodeAttribute: (options) =>
      new Promise((resolve, reject) => {
        const element = getElement(options);
        element ? resolve(element.getAttribute(options.attribute)) : reject();
      }),
    click: (options) =>
      new Promise((resolve, reject) => {
        if (!options.all) {
          const element = getElement(options);
          element && element.click();
          return element ? resolve() : reject();
        }

        const elements = document.querySelectorAll(options.selector);
        if (!elements.length) {
          return reject();
        }
        for (let i = 0; i < elements.length; i++) {
          elements[i].click();
        }
        resolve();
      }),
    next: (options) => Promise.reject(),
  };

  function CreateActionWrapper(actionConfig) {
    if (Array.isArray(actionConfig)) {
      let prevAction = Promise.resolve();
      actionConfig.forEach((action) => {
        prevAction = prevAction.then(() => ACTIONS[action.action || 'getNodeText'](action));
      });

      return prevAction;
    }

    return ACTIONS[actionConfig.action || 'getNodeText'](actionConfig);
  }

  function saveResume(result) {
    storedResume = result;
    if (shouldSendDataWhenResumeBecameReady) {
      sendResume();
      shouldSendDataWhenResumeBecameReady = false;
    }
  }
  function sendResume() {
    if (storedResume === null) {
      shouldSendDataWhenResumeBecameReady = true;
    }
    const message = Object.assign({ to: 'iframe' }, storedResume);
    chrome.runtime.sendMessage({ action: 'saveResume', data: message }, () => {
      storedResume = null;
    });
  }

  chrome.runtime.sendMessage({ action: 'getConfig', location: window.location.href }, (response) => {
    let resultPromise;
    if (!response.parsingParams) {
      resultPromise = Promise.resolve({
        status: 'configError',
      });
    } else if (response.state === 'disabled') {
      resultPromise = Promise.resolve({
        status: 'unsupported',
        link: window.location.href,
      });
    } else if (response.state === 'enabled') {
      resultPromise = Promise.resolve({
        status: 'wrongPage',
      });
    } else {
      const resumeFetchers = response.parsingParams.config;
      const fetcher = resumeFetchers.find((fetcher) => window.location.host.indexOf(fetcher.pattern) !== -1);
      if (fetcher.type === 'hh') {
        resultPromise = Promise.resolve({
          status: 'ok',
          resume: {
            type: 'hh',
            link: window.location.href,
          },
        });
      } else {
        resultPromise = getResume(fetcher.type, fetcher.config);
      }
    }
    resultPromise.then(saveResume);
  });

  function getResumeText(actions) {
    return new Promise((resolve) => {
      let currentAction = 0;
      function tryNextAction() {
        if (currentAction >= actions.length) {
          resolve(null);
        } else {
          CreateActionWrapper(actions[currentAction++])
            .then(resolve, tryNextAction)
            .catch(tryNextAction);
        }
      }

      tryNextAction();
    });
  }

  function getElement(options) {
    const elements = document.querySelectorAll(options.selector);
    const index = options.index || 0;
    if (elements.length > index) {
      return elements[index];
    }
  }

  function getResumeParts(parts) {
    return parts.map(function(selector) {
      const elements = document.querySelectorAll(selector);
      return [].map.call(elements, (element) => element.innerHTML).join(' ');
    });
  }

  function getResume(type, config) {
    const preparePromise = config.prepare ? getResumeText(config.prepare) : Promise.resolve();

    return preparePromise.then(() => {
      let promises = [getResumeText(config.name)];
      promises.push(config.cell ? getResumeText(config.cell) : Promise.resolve(null));
      promises.push(config.email ? getResumeText(config.email) : Promise.resolve(null));
      promises.push(config.cellImage ? getResumeText(config.cellImage) : Promise.resolve(null));

      return Promise.all(promises).then((values) => {
        let name = values[0];
        let cell = values[1];
        let email = values[2];
        let cellImage = values[3];
        if (name && (cell || email || cellImage)) {
          name = name.split(' ');

          let resumeParts = getResumeParts(config.resume);
          let contacts = [];

          if (cell) {
            contacts.push({
              type: 'cell',
              value: cell,
            });
          }

          if (email) {
            contacts.push({
              type: 'email',
              value: email,
            });
          }

          return Promise.resolve({
            status: 'ok',
            resume: {
              firstName: name[1] || name[0],
              lastName: name[1] && name[0],
              middleName: name[2],
              cellImage: cellImage,
              contacts: contacts,
              resume: {
                type: type,
                text: '<div>' + resumeParts.join(' ') + '</div>',
                link: window.location.href,
              },
            },
          });
        } else {
          if (config.buyContacts.some((item) => document.querySelector(item))) {
            return Promise.resolve({ status: 'auth' });
          } else {
            return Promise.resolve({
              status: 'error',
              report: {
                type: type,
                link: window.location.href,
                data: {
                  name: name,
                  cell: cell,
                  email: email,
                },
                html: document.body.innerHTML,
              },
            });
          }
        }
      });
    });
  }
})();

