console.log('index.js');

const script = "(function(){console.log('I work inside the script tag, from index.js');})();";

const scriptEl = document.createElement('script');
scriptEl.textContent = script;
document.body.appendChild(scriptEl);

window.test = '123';

document.addEventListener('blur', (e) => {
  if (document.hasFocus()) {
    console.log('[blur] focus');
  } else {
    console.log('[blur] focus lost');
  }
});

document.addEventListener('visibilitychange', (e) => {
  if (document.hasFocus()) {
    console.log('focus');
  } else {
    console.log('focus lost');
  }
});

// const mo = new MutationObserver((...args) => {
//   console.log(args);
// });
// const config = {
//   attributes: true,
//   attributeOldValue: true,
//   characterData: true,
//   characterDataOldValue: true,
//   childList: true,
//   subtree: true,
// };

// document.querySelectorAll = new Proxy(document.querySelectorAll, {
//   apply: (target, thisValue, args) => {
//     const error = new Error('test');
//     console.log('CAPTURED');
//     console.log(args);
//     console.log(error.toString());
//     console.log(error.stack.toString());
//     throw new Error();
//     console.log('CAPTURE END');
//     return target.apply(thisValue, args);
//   },
// });
// mo.observe(document, config);
// console.log('Proxy and MO subscribed');
